const db = require('./db')
const utils = require('./utils')
const multer=require('multer')
const express = require('express')
const upload = multer({ dest: 'images/'})


const router = express.Router()

router.get('/', (request, response) => {
    const connection = db.connect()
    const statement = `select * from PGdetails`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

router.post('/add', upload.single('THUMBNAIL'),(request, response) => {
    
    const {PGCITY, PGAREA, PGNAME, PGTYPE,sing_Share_avi,double_Share_avi,three_Share_avi,four_Share_avi,OID} = request.body
    const THUMBNAIL=request.file.filename
    const connection = db.connect()
    const statement = `insert into PGdetails (PGCITY, PGAREA, PGNAME, PGTYPE,sing_Share_avi,double_Share_avi,three_Share_avi,four_Share_avi,OID,THUMBNAIL) values ('${PGCITY}', '${PGAREA}', '${PGNAME}', '${PGTYPE}',${sing_Share_avi},${double_Share_avi},${three_Share_avi},${four_Share_avi},${OID},'${THUMBNAIL}')`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

router.get('/details/:id', (request, response) => {
    const {id} = request.params
    const connection = db.connect()
    const statement = `select PGdetails.*, OWNERDETAILS.OFNAME as owner_name from PGdetails, OWNERDETAILS where PGdetails.OID = OWNERDETAILS.OID and PGdetails.PGID = ${id}`
    console.log(statement)
    connection.query(statement, (error, PGs) => {
        connection.end()
        if (PGs.length > 0) {
            response.send(utils.createResult(error, PGs[0]))
        } else {
            response.send(utils.createResult('pg does not exist'))
        }
    })
})
module.exports = router