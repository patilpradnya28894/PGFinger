const db = require('./db')
const utils = require('./utils')
const express = require('express')
const cryptoJs = require('crypto-js')


const router = express.Router()

router.get('/', (request, response) => {
    //const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()
    const statement = `select * from ClientDetails`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

router.post('/login', (request, response) => {
    const {CEMAIL, password} = request.body
    const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()
    const statement = `select * from ClientDetails where CEMAIL = '${CEMAIL}' and password = '${password}'`
    connection.query(statement, (error, users) => {
        connection.end()
        
        if (users.length == 0) {
            response.send(utils.createResult('user does not exist'))
        } else {
            const user = users[0]
            const info = {
                //username: user['username'],
                Email: user['email'],
                password: user['password']
            }
            response.send(utils.createResult(error, users))
        }
    })
})



router.post('/register', (request, response) => {
    const {CNAME ,CEMAIL,password,CMOBILE} = request.body
   // const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()

    const statement1 = `select * from ClientDetails where CEMAIL = '${CEMAIL}' and password='${password}'`
    connection.query(statement1, (error, users) => {

        if (users.length == 0) {
            
            const statement = `insert into ClientDetails (CNAME ,CEMAIL,password,CMOBILE) values ('${CNAME}','${CEMAIL}','${password}',${CMOBILE})`
            connection.query(statement, (error, data) => {
                connection.end()
                response.send(utils.createResult(error, data))
            })
        } else {
            connection.end()
            response.send(utils.createResult('email exists. please use another email.'))
        }


    })

    
})


router.delete('/:id', (request, response) => {
    const {id} = request.params
   
    const connection = db.connect()
    const statement = `delete from ClientDetails where CID = ${id}`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

module.exports = router