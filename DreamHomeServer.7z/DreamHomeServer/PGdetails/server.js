const express = require('express')
const bodyParser = require('body-parser')
const routerPGdetails = require('./addPG')
const routercdetails = require('./cdetails')
const routerownerdetails = require('./ownerdetails')
const routeradminlogin = require('./adminlogin')
const routerPGList=require('./PGlistForUsers')
const routerMyPG=require('./MyPG')

const app=express()

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(express.static('images'))

app.use(bodyParser.json())
app.use('/addPG', routerPGdetails)
app.use('/cdetails', routercdetails)
app.use('/ownerdetails',routerownerdetails)
app.use('/adminlogin',routeradminlogin)
app.use('/PGlistForUsers',routerPGList)
app.use('/MyPG',routerMyPG)
app.use(express.static('images'))

app.listen(5000, '0.0.0.0',() =>{
    console.log('server started at port no 5000')
})