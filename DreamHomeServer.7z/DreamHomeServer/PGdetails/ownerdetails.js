const db = require('./db')
const utils = require('./utils')
const express = require('express')

const router = express.Router()

router.get('/', (request, response) => {
    const connection = db.connect()
    const statement = `select * from OWNERDETAILS`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})


router.post('/login', (request, response) => {
    const {OEMAIL, OPASSWORD} = request.body
  //  const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()
    const statement = `select * from OWNERDETAILS where OEMAIL = '${OEMAIL}' and OPASSWORD = '${OPASSWORD}'`
    connection.query(statement, (error, owners) => {
        connection.end()
        
        if (owners.length == 0) {
            response.send(utils.createResult('user does not exist'))
        } else {
            const owner = owners[0]
            const info = {
                //username: user['username'],
                Email: owner['email'],
                password: owner['password']
            }
            response.send(utils.createResult(error, owners))
        }
    })
})

router.post('/owner_reg', (request, response) => {
    const {OEMAIL, OPASSWORD, OFNAME, PGADD,PINCODE} = request.body
    //const thumbnail = request.file.filename

    const connection = db.connect()
    const statement = `insert into OWNERDETAILS (OEMAIL, OPASSWORD, OFNAME, PGADD,PINCODE) values ('${OEMAIL}', '${OPASSWORD}', '${OFNAME}', '${PGADD}',${PINCODE})`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})





module.exports = router



