const db = require('./db')
const utils = require('./utils')
const express = require('express')


const router = express.Router()

router.get('/info/:id', (request, response) => {
    const {id} = request.params
    const connection = db.connect()
    const statement = `select p.PGID,PGCITY,PGAREA, PGNAME, PGTYPE,THUMBNAIL, sing_share_avi,double_share_avi,three_share_avi,four_share_avi,OFNAME,SIG_SHARE,DOUBLE_SHARE,THREE_SHARE,FOUR_SHARE from PGdetails p inner join OWNERDETAILS o on p.OID = o.OID inner join RENT r on  o.OID = r.OID where p.PGID=${id} `
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

router.get('/facilities', (request, response) => {
    
    const connection = db.connect()
    const statement = `select  * from facilities;`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

module.exports = router