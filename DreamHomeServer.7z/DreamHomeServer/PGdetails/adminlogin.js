const db = require('./db')
const utils = require('./utils')
const express = require('express')
const cryptoJs = require('crypto-js')


const router = express.Router()

router.get('/', (request, response) => {
    //const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()
    const statement = `select * from ADMINDETAILS`
    connection.query(statement, (error, data) => {
        connection.end()
        response.send(utils.createResult(error, data))
    })
})

router.post('/login', (request, response) => {
    const {EMAIL, PASSWORD} = request.body
    //const encryptedPassword = '' + cryptoJs.MD5(password)
    const connection = db.connect()
    const statement = `select * from ADMINDETAILS where EMAIL = '${EMAIL}' and PASSWORD = '${PASSWORD}'`
    connection.query(statement, (error, admins) => {
        connection.end()
        
        if (admins.length == 0) {
            response.send(utils.createResult('user does not exist'))
        } else {
            const admin = admins[0]
            const info = {
                //username: user['username'],
                Email: admin['email'],
                password: admin['password']
            }
            response.send(utils.createResult(error, admin))
        }
    })
})






module.exports = router