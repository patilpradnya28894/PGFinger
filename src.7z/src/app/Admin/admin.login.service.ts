import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AdminLoginService {

    url = 'http://localhost:5000/adminlogin'

    constructor(private http: HttpClient) { }

    login(EMAIL: string, PASSWORD: string){
        const body = {
            EMAIL: EMAIL,
            PASSWORD: PASSWORD
        }
        return this.http.post(this.url + '/login',body)
    }
    
    }
