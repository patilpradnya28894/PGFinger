import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminLoginService } from './admin.login.service';
import * as toastr from 'toastr'

@Component({
    selector: 'adminside-login',
    templateUrl: 'admin.login.component.html',
    styleUrls:[('admin.login.component.css')]
})
export class LoginComponent implements OnInit {
    EMAIL = ''
    PASSWORD = ''
    constructor(private router:Router,
        private loginservice:AdminLoginService) { }

    ngOnInit() { }
onLogin(){
    if (this.EMAIL.length == 0) {
                    toastr.error('enter valid email')
                  } else if (this.PASSWORD.length == 0) {
                    toastr.error('enter valid password')
                   } else{
                       this.loginservice
                       .login(this.EMAIL,this.PASSWORD)
                       .subscribe(response => {
                           
                           if(response['status'] == 'success'){
                            toastr.success('authenticated')
                            this.router.navigate(['/admin-list'])
                           }else{
                               toastr.error(response['error'])
                           }
        
                       })
                        
                    }
            }
}

