import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AdminRegisterComponent } from './user/register/admin.register.component';
import { AdminLoginComponent } from './user/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule} from '@angular/forms'

import { AdminService } from './user/admin.service';
import { RouterModule,Route } from '@angular/router';
import { PGListComponent } from './PGdetails/list/list.component';
import { PgService } from './PGdetails/PG.service';
import { AddPGComponent } from './PGdetails/add/pg.add.component';
import { AddPGService } from './PGdetails/add/addpg.service';
import { HomeComponent } from './home/home.component';
import { OwnerLoginComponent } from './owner/owner.login.component';
import { OwnerService } from './owner/owner.service';
import { OwnerRegComponent } from './owner/OwnerReg/owner.reg.component';
import { LoginComponent } from './Admin/admin.login.component';
import { AdminLoginService } from './Admin/admin.login.service';
import { UserPGComponent } from './user/userList/userList.component';
import { UserListService } from './user/userList/userList.service';
import { PGinfoComponent } from './user/PGinfo/PGinfo.component';
import { PGinfoService } from './user/PGinfo/PGinfo.service';
import { facilitiesComponent } from './user/facilities/facilities.component';
import { OwnerAddPGComponent } from './owner/ownerAdd/ownerAdd.component';
// import { OwnerRegComponent, OwnerRegisterComponent } from './owner/OwnerReg/owner.reg.component';


const routes:Route[]=[
 // {path:'',redirectTo:'/admin-login',pathMatch:'full'},
  //{path:'',component:AdminLoginComponent},
  {path: '',component:HomeComponent},
  
  {path:'admin-login',component:AdminLoginComponent},
  {path:'admin-register',component:AdminRegisterComponent},
  {path:'admin-list',component:PGListComponent},
  {path:'admin-add',component:AddPGComponent},
  {path:'owner-login',component:OwnerLoginComponent},
   {path:'owner-register',component:OwnerRegComponent},
   {path:'adminside-login',component:LoginComponent},
   {path:'PG-UserList',component:UserPGComponent},
   {path:'my-pg',component:PGinfoComponent},
   {path:'book-pg',component:facilitiesComponent}
   
   


]


@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    AdminRegisterComponent,
    PGListComponent,
    AddPGComponent,
    
    HomeComponent,
    OwnerLoginComponent,
    OwnerRegComponent,
    LoginComponent,
    UserPGComponent,
    PGinfoComponent,
    facilitiesComponent,
    OwnerAddPGComponent
    //forgetpassword

    


    
  ],
  imports: [






    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes),
    BrowserModule
  ],
  providers: [
    AdminService,
    PgService,
    AddPGService,
    OwnerService,
    AdminLoginService,
    UserListService,
    PGinfoService


  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
