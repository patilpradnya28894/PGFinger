import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class PgService {

  url = 'http://localhost:5000/addPG'

  constructor(private http: HttpClient) { }

  getAllPG() {
    return this.http.get(this.url)
  }

  addPG(PGCITY: string, PGAREA: string,PGNAME: string, PGTYPE: string,sing_Share_avi: number,double_Share_avi: number,three_Share_avi: number,four_Share_avi: number,THUMBNAIL: any) {

    const body = new FormData()

    body.append('PGCITY', PGCITY)
    body.append('PGAREA', PGAREA)
    body.append('PGNAME', PGNAME)
    body.append('PGTYPE', PGTYPE)
    body.append('sing_Share_avi', '' +sing_Share_avi)
    body.append('double_Share_avi', ''+double_Share_avi)
    body.append('three_Share_avi','' +three_Share_avi)
    body.append('four_Share_avi',''+ four_Share_avi)
    body.append('THUMBNAIL', THUMBNAIL)
   
    return this.http.post(this.url, body)
  }
}
