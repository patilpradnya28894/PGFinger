import { Component, OnInit } from '@angular/core';
import { AddPGService } from './addpg.service';
import { Router } from '@angular/router';

@Component({
    selector: 'pg-add',
    templateUrl: './pg.add.component.html',
    styleUrls:['./pg.add.component.css']
})

export class AddPGComponent implements OnInit {

    PG:any[]
    PGCITY: string
        PGAREA: string
        PGNAME: string
        PGTYPE: string
        sing_Share_avi:number
        double_Share_avi:number
        three_Share_avi:number
        four_Share_avi:number
        OID:number
        THUMBNAIL:any

    constructor(
        private router: Router,
        private addPGService:AddPGService) { 
        this.addPGService
        .getPG()
        .subscribe(response=>{
            if (response['status']=='success'){
                this.PG=response['data']
            }else {
                alert('error')
            }

        })
        
    }

    ngOnInit() { }
    onSelectFile(event){
        this.THUMBNAIL=event.target.files[0]
        
    }

    onAdd() {
        //console.log(this.PGCITY, this.PGAREA, this.PGNAME, this.PGTYPE,this.sing_Share_avi,this.double_Share_avi,this.three_Share_avi,this.four_Share_avi,this.THUMBNAIL)
        this.addPGService
          .addpg(this.PGCITY, this.PGAREA, this.PGNAME, this.PGTYPE,this.sing_Share_avi,this.double_Share_avi,this.three_Share_avi,this.four_Share_avi,this.OID,this.THUMBNAIL)
          .subscribe(response => {
            if (response['status'] == 'success') {
              alert('Added PG Successfully')
              this.router.navigate(['/admin-list'])
            } else {
              alert('error while adding PG')
              console.log(response['error'])
            }
          })
      }
    
}



