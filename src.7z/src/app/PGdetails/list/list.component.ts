import { Component, OnInit } from '@angular/core';
import { PgService } from '../PG.service';
import { Router } from '@angular/router';

@Component({
    selector: 'pg-list',
    templateUrl: './list.component.html',
    styleUrls: ['./list.component.css']
})

export class PGListComponent implements OnInit {

  PGs:any[]

  constructor(
    private router: Router,
    private pgService:PgService) {
    this.pgService
    .getAllPG()
    .subscribe(responce =>{
      if (responce['status']=='success'){
        this.PGs = responce['data']
      }else {
        console.log(responce['error'])
      }
    })
    

   }

  ngOnInit() { }

  onAddPG(){
    this.router.navigate(['./admin-add'])
  }
  
}



