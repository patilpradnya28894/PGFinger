import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserListService } from './userList.service';



@Component({
    selector: 'PG-UserList',
    templateUrl: 'userList.component.html',
    styleUrls:['userList.component.css']
})
export class UserPGComponent implements OnInit {
    PGs:any[]

    constructor( private router: Router,
        private userListService:UserListService) { 
          this.userListService
          .getAllPG()
          .subscribe(responce =>{
            if (responce['status']=='success'){
              this.PGs = responce['data']
            }else {
              console.log(responce['error'])
            }
          })
        
        }
    ngOnInit() { 

    }

    onShow(id: number){
      this.router.navigate(['./my-pg'],{ queryParams: { id: id } })
    }
}






