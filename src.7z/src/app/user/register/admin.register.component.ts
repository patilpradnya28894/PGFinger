import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import * as toastr from 'toastr'
import {Router} from '@angular/router';

@Component({
    selector: 'app-admin-register',
    templateUrl: './admin.register.component.html',
    styleUrls: ['./admin.register.component.css']
})

export class AdminRegisterComponent implements OnInit {
    CNAME =''
    CEMAIL = ''
    password =''
    CMOBILE:number
    

    constructor(
        private router: Router,
        private adminService: AdminService) { }

    ngOnInit() { }
    onRegister(){
      //console.log(this.FullName+' '+this.Email+' '+this.Password)
        if (this.CNAME.length == 0) {
            toastr.error('enter valid name')
          }else if(this.CMOBILE==0){
            toastr.error('enter valid mobile')
          } else if (this.CEMAIL.length == 0) {
            toastr.error('enter valid email')
          } else if (this.password.length == 0) {
            toastr.error('enter valid password')
          } else {
            this.adminService
              .registerAdmin(this.CNAME, this.CEMAIL, this.password,this.CMOBILE)
              .subscribe(response => {
                if (response['status'] == 'success') {
                  toastr.success('registered successfully')
                  this.router.navigate(['/admin-login'])
                } else {
                  toastr.error(response['error'])
                }
              })
          }
        }
      }
    
