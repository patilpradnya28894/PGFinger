import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AdminService {

    url = 'http://localhost:5000/cdetails'

    constructor(private http: HttpClient) { }

    login(CEMAIL: string, password: string){
        const body = {
            CEMAIL: CEMAIL,
            password: password
        }
        return this.http.post(this.url + '/login',body)
    }
    registerAdmin(CNAME: string,CEMAIL: string, password: string,CMOBILE: number){
        const body = {
            CNAME: CNAME,
            CEMAIL: CEMAIL,
            
            password: password,
            CMOBILE:CMOBILE
        }
        return this.http.post(this.url + '/register',body)
    }

    // show(PGCITY: string,PGAREA: string, PGNAME: string, PGTYPE: string,sing_Share_avi: number,double_Share_avi: number,three_Share_avi: number,four_Share_avi: number){
    //     const body = {
    //         PGCITY: PGCITY,
    //         PGAREA: PGAREA,
    //         PGNAME: PGNAME,
    //         PGTYPE: PGTYPE,
    //         sing_Share_avi:sing_Share_avi,
    //         double_Share_avi: double_Share_avi,
    //         three_Share_avi: three_Share_avi,
    //         four_Share_avi: four_Share_avi,
    //     }
    //     return this.http.post(this.url,body)
    // }
    }
