import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import * as toastr from 'toastr'
import { Route, Router } from '@angular/router';
@Component({
    selector: 'app-admin-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})

export class AdminLoginComponent implements OnInit {
    CEMAIL = ''
    password = ''
    constructor(
    private router:Router, 
    private adminService: AdminService) {}

    ngOnInit() { }

    onLogin(){
       if (this.CEMAIL.length == 0) {
            toastr.error('enter valid email')
          } else if (this.password.length == 0) {
            toastr.error('enter valid password')
           } else{
               this.adminService
               .login(this.CEMAIL,this.password)
               .subscribe(response => {
                   
                   if(response['status'] == 'success'){
                    toastr.success('authenticated')
                    this.router.navigate(['/PG-UserList'])
                   }else{
                       toastr.error(response['error'])
                   }

               })
                
            }
    }
}  