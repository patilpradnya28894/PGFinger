import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class PGinfoService {

  url = 'http://localhost:5000/MyPG'

  constructor(private http: HttpClient) { }
  neededFacilitiesErr: Boolean = true
  facility:any[]
 

  getPGDetails(id: number) {
    return this.http.get(this.url + '/info/' + id)
  }

  getSelectedFacilityValue() {
    this.facility = [];
    this.facility.forEach((control, i) => {
      if (control.value) {
        this.facility.push(this.facility[i]);
      }
    });

    this.neededFacilitiesErr =  this.facility.length > 0 ? false : true;
  }

    // return this.http.get(this.url + '/facilities')
  }


  

 
  
  

  


