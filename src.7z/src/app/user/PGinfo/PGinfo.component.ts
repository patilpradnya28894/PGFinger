import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as toastr from 'toastr'
import { Route, Router } from '@angular/router';
import { PGinfoService } from './PGinfo.service';

@Component({
  selector: 'app-pg-details',
  templateUrl: './PGinfo.component.html',
  styleUrls: ['./PGinfo.component.css']
})

export class PGinfoComponent implements OnInit {
  pg: any[]

  constructor(private router:Router,
    private pginfoService: PGinfoService,
    private activatedRoute: ActivatedRoute) {

    const id = activatedRoute.snapshot.queryParams['id']
    if (id) {
      this.pginfoService
        .getPGDetails(id)
        .subscribe(response => {
          if (response['status'] == 'success') {
            this.pg = response['data']
            
            
          }
        })
    }
  }

  ngOnInit() { }
  onBook(id){
    this.router.navigate(['./book-pg'],{ queryParams: { id: id } })
  }
  
}
