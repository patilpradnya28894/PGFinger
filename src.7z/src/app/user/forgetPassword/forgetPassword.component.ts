
// import { Component,OnInit } from '@angular/core';
// //import { UserService } from '../user.service';
// import { Router } from '@angular/router';
// import * as toastr from 'toastr';

// @Component({
//     selector: 'app-user-forgot-password',
//     templateUrl: './forgetPassword.component.html',
//     styleUrls: ['./forgetPassword.component.css']
// })

// export class forgetpassword implements OnInit {
//     email:string
//     constructor(private router: Router,
//         private service: UserService) { }

//     ngOnInit() { }

//     onSend(){
//         this.service
//         .forgotPassword(this.email)
//         .subscribe(response =>{
//             if(response['status']=='success'){
//                 this.router.navigate(['/user-login'])
//             }else{
//                 toastr.error(response['error'])
//             }
//         })
//     }
// }