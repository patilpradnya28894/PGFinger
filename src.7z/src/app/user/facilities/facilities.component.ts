import { Component, OnInit ,forwardRef} from '@angular/core';
import { FormBuilder,FormControl} from '@angular/forms';
import { PGinfoService } from '../PGinfo/PGinfo.service';
import { ActivatedRoute } from '@angular/router';



@Component({
    selector: 'facilities',
    templateUrl: './facilities.component.html',
  styleUrls: ['./facilities.component.css']
})

export class facilitiesComponent implements OnInit {
  
    facility:any[]

    constructor(private activatedRoute: ActivatedRoute,
        private pginfoService:PGinfoService,
        ) {
  }
        
    ngOnInit() { 
      //selectedFacility:this.addFacilitiesControls()
    }

   

  
}