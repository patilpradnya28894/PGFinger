import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class OwnerService {

    url = 'http://localhost:5000/ownerdetails'

    // getAllOwners() {
    //     return this.http.get(this.url)
    //   }
    

    constructor(private http: HttpClient) { }

    getPG() {
        return this.http.get(this.url)
      }
    login(CEMAIL: string, OPASSWORD: string){
        const body = {
            OEMAIL: CEMAIL,
            OPASSWORD: OPASSWORD,
            
        }
        return this.http.post(this.url+'/login',body)
    }
    
    registerOwner(OEMAIL: string,OPASSWORD: string, OFNAME: string,PGADD: string,PINCODE:number){
        const body = {
            OEMAIL: OEMAIL,
            OPASSWORD: OPASSWORD,
            
            OFNAME: OFNAME,
            PGADD:PGADD,
            PINCODE:PINCODE
        }
        return this.http.post(this.url + '/owner_reg',body)
    }

    addpg(PGCITY: string, PGAREA: string, PGNAME: string, PGTYPE: string,sing_Share_avi: number,double_Share_avi: number,three_Share_avi: number,four_Share_avi: number,OID:number,THUMBNAIL: any) {
    
        const body = new FormData ()
           body.append('PGCITY', PGCITY)
           body.append('PGAREA', PGAREA)
           body.append('PGNAME', PGNAME)
           body.append('PGTYPE', PGTYPE)
           body.append('sing_Share_avi',''+sing_Share_avi)
           body.append('double_Share_avi',''+ double_Share_avi)
           body.append('three_Share_avi', ''+ three_Share_avi)
           body.append('four_Share_avi', ''+ four_Share_avi)
           body.append('OID', ''+ OID)
           body.append('THUMBNAIL', THUMBNAIL)
           
            console.log(body)
    
        return this.http.post(this.url +'/add', body)
      }
}
    
