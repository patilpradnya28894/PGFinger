import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as toastr from 'toastr'
import { OwnerService } from '../owner.service';

@Component({
    selector: 'owner-register',
    templateUrl: 'owner.reg.component.html',
    styleUrls:[('owner.reg.component.html')]
})

export class OwnerRegComponent implements OnInit {
    OEMAIL =''
    OPASSWORD = ''
    OFNAME =''
    PGADD:''
    PINCODE:number

    constructor(private router: Router,
        private ownerService:OwnerService) { }

    ngOnInit() { }
    onRegister(){
              
                if (this.OEMAIL.length == 0) {
                    toastr.error('enter valid name')
                  }else if(this.OPASSWORD.length==0){
                    toastr.error('enter valid mobile')
                  } else if (this.OFNAME.length == 0) {
                    toastr.error('enter valid email')
                  } else if (this.PGADD.length == 0) {
                    toastr.error('enter valid password')
                  } else {
                    this.ownerService
                      .registerOwner(this.OEMAIL, this.OPASSWORD, this.OFNAME,this.PGADD,this.PINCODE)
                      .subscribe(response => {
                        if (response['status'] == 'success') {
                          toastr.success('registered successfully')
                          this.router.navigate(['/owner-login'])
                        } else {
                          toastr.error(response['error'])
                        }
                      })
                  }
                }

}



