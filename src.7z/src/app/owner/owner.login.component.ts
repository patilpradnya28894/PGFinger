import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import * as toastr from 'toastr'
import { OwnerService } from './owner.service';

@Component({
    selector: 'owner-login',
    templateUrl: 'owner.login.component.html',
    styleUrls:['owner.login.component.css']
})

export class OwnerLoginComponent implements OnInit {
    OEMAIL=''
    OPASSWORD=''

   constructor( private router: Router,
    private ownerService:OwnerService) {  }

    ngOnInit() { }
    onownerLogin()
        {
            if(this.OEMAIL.length==0)
            {
                toastr.error('Enter valid Email')
            }
            else if (this.OPASSWORD.length==0)
            {
            toastr.error('Enter valid password')
            }
            else
            {
               this.ownerService
               .login(this.OEMAIL,this.OPASSWORD)
               .subscribe(response => 
                {
                    if(response['status'] == 'success')
                    {
                    toastr.success('authenticated')
                    
                    this.router.navigate(['/admin-add'])
                   }
                   else
                   {
                       toastr.error(response['error'])
                   }
                })
            }
        }
    }

    









